export type ProjectCategory = 'Todos' | 'Landing Page' | 'Institucional' | 'E-commerce';

export interface PortfolioProject {
  id: string;
  title: string;
  client: string;
  category: Exclude<ProjectCategory, 'Todos'>;
  deliveryTime: string;
  headlineMetric: string;
  summary: string;
  challenge: string;
  solution: string;
  outcome: string;
  image: string;
  imageAlt: string;
  imageClassName?: string;
  deliverables: string[];
}

export interface ServiceItem {
  number: string;
  title: string;
  subtitle: string;
  description: string;
  highlight: string;
  span: 'wide' | 'narrow';
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  metric: string;
  quote: string;
}

export const CONTACT_INFO = {
  brand: 'KAVO Studio',
  logoUrl: '/assets/aistudio/59867f48-7ee1-4965-8e28-f5b1baaf0bd6_ca21a853.png',
  whatsappNumber: '5549999648153',
  whatsappDisplay: '(49) 99964-8153',
  instagramUrl: 'https://www.instagram.com/kavostudio8/',
  instagramHandle: '@kavostudio8',
  primaryCtaLabel: 'Solicitar um site para minha empresa',
  defaultWhatsappMessage:
    'Olá, KAVO Studio! Quero solicitar um site para minha empresa e elevar minha marca para outro nível.',
};

export function buildWhatsappUrl(message: string = CONTACT_INFO.defaultWhatsappMessage): string {
  return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const HERO_IMAGE = {
  src: '/assets/aistudio/image_21f0d264.png',
  alt: 'Site corporativo Sol Azul desenvolvido em azul marinho e preto com chamada Rigor contábil para decisões empresariais seguras',
};

export const HERO_METRICS = [
  {
    value: 'Mesmo dia',
    label: 'Prazo de entrega e publicação',
  },
  {
    value: '100%',
    label: 'Foco em conversão e faturamento',
  },
  {
    value: '< 1,2s',
    label: 'Velocidade otimizada para anúncios',
  },
  {
    value: 'Brasil',
    label: 'Atendimento direto em todo o país',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    number: '01.',
    title: 'Landing Pages de Alta Conversão',
    subtitle: 'Tráfego Pago · Captação Imediata',
    description:
      'Páginas criadas para transformar cliques de Google Ads e Instagram em mensagens reais no WhatsApp da sua equipe comercial. Copywriting persuasivo, velocidade extrema e leitura clara no celular.',
    highlight: 'Entrega no mesmo dia',
    span: 'wide',
  },
  {
    number: '02.',
    title: 'Sites Institucionais Premium',
    subtitle: 'Autoridade · Posicionamento B2B',
    description:
      'Apresente sua empresa com padrão executivo. Estrutura completa para transmitir confiança imediata para clientes de alto valor e decisores.',
    highlight: 'Design sob medida',
    span: 'narrow',
  },
  {
    number: '03.',
    title: 'Lojas Virtuais & Catálogos',
    subtitle: 'Vendas Online · Ticket Médio Maior',
    description:
      'Vitrines digitais rápidas com organização estratégica de produtos, provas sociais e finalização ágil para você vender sem depender só de redes sociais.',
    highlight: 'Pronto para escalar',
    span: 'narrow',
  },
  {
    number: '04.',
    title: 'Reformulação Completa de Sites',
    subtitle: 'Modernização · Recuperação de Vendas',
    description:
      'Se o seu site atual é lento, confuso ou passa imagem amadora, nós reestruturamos toda a arquitetura visual e comercial em tempo recorde para destravar seu faturamento.',
    highlight: 'Publicação ágil',
    span: 'wide',
  },
];

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'faria-lima-1568',
    title: 'Faria Lima 1568',
    client: 'Faria Lima 1568 · Jardim Paulistano, SP',
    category: 'Institucional',
    deliveryTime: 'Entregue no mesmo dia',
    headlineMetric: '+118% em agendamentos com hora marcada',
    summary:
      'Site institucional editorial para salão de beleza autoral nos Jardins, destacando especialidades em cabelo, cor e atendimento exclusivo.',
    challenge:
      'A marca precisava transmitir o padrão sofisticado do atendimento presencial e facilitar o agendamento direto sem intermediários.',
    solution:
      'Estruturamos uma vitrine editorial elegante com apresentação dos serviços, história do espaço e botão direto para reserva pelo WhatsApp.',
    outcome:
      'O volume de solicitações de horário pelo WhatsApp cresceu 118% já nas primeiras semanas após a publicação.',
    image: '/assets/aistudio/image_5bd4808f.png',
    imageAlt: 'Site institucional Faria Lima 1568 com chamada Beleza autoral no coração da Faria Lima e botão para WhatsApp',
    imageClassName: 'object-cover object-center',
    deliverables: ['Site Institucional Editorial', 'Posicionamento de Marca', 'Integração WhatsApp'],
  },
  {
    id: 'bichos-e-coisas',
    title: 'Bichos & Coisas Pet Shop',
    client: 'Bichos & Coisas · Vila Guilherme, SP',
    category: 'E-commerce',
    deliveryTime: 'Entregue no mesmo dia',
    headlineMetric: '+64% em agendamentos e pedidos online',
    summary:
      'Plataforma digital completa para pet shop e clínica veterinária, unindo vitrine de produtos, carrinho de pedidos e agendamento direto no WhatsApp.',
    challenge:
      'Os tutores da região precisavam consultar serviços de banho e tosa e encomendar produtos sem enfrentar filas no atendimento telefônico.',
    solution:
      'Criamos uma interface leve e acolhedora com catálogo integrado ao carrinho de pedidos, galeria e botão direto para fechar pelo WhatsApp.',
    outcome:
      'O volume de agendamentos de banho e tosa somado aos pedidos de produtos cresceu 64% já no primeiro mês no ar.',
    image: '/assets/aistudio/image_a296e884.png',
    imageAlt: 'Site da Bichos & Coisas Pet Shop com chamada Cuidado completo que faz o rabo abanar e botão para WhatsApp',
    imageClassName: 'object-cover object-center',
    deliverables: ['Vitrine de Produtos', 'Carrinho de Pedidos', 'Agendamento WhatsApp'],
  },
  {
    id: 'odontoclinic-vila-mariana',
    title: 'Odontoclinic Vila Mariana',
    client: 'Odontoclinic · Vila Mariana, SP',
    category: 'Landing Page',
    deliveryTime: 'Entregue no mesmo dia',
    headlineMetric: '3,2x mais avaliações agendadas pelo WhatsApp',
    summary:
      'Página clínica de alta conversão para odontologia individualizada na Vila Mariana, destacando planejamento digital e agendamento rápido.',
    challenge:
      'Os anúncios locais atraíam cliques, mas os pacientes não encontravam autoridade clínica nem um caminho direto para agendar avaliação.',
    solution:
      'Construímos uma landing page limpa e confiável com destaque para o registro CRO-SP, diferenciais do consultório e botão direto no WhatsApp.',
    outcome:
      'O custo por agendamento caiu pela metade e as avaliações semanais multiplicaram por 3,2x.',
    image: '/assets/aistudio/image_2e879b10.png',
    imageAlt: 'Site da Odontoclinic Vila Mariana com chamada Precisão clínica para um sorriso natural e botão para WhatsApp',
    imageClassName: 'object-cover object-center',
    deliverables: ['Landing Page Clínica', 'Copy de Autoridade', 'Agendamento WhatsApp'],
  },
  {
    id: 'hamburguer-seu-oswaldo',
    title: 'Hambúrguer seu Oswaldo',
    client: 'Hambúrguer seu Oswaldo · Ipiranga, SP',
    category: 'Landing Page',
    deliveryTime: 'Entregue no mesmo dia',
    headlineMetric: '+82% em pedidos diretos pelo WhatsApp',
    summary:
      'Site de alta conversão para hamburgueria tradicional no Ipiranga, com cardápio direto e atendimento imediato pelo WhatsApp.',
    challenge:
      'Os clientes precisavam encontrar o cardápio e fazer pedidos rapidamente sem pagar taxas altas em aplicativos de entrega.',
    solution:
      'Criamos uma página impactante com fotografia de alto contraste, navegação direta para o cardápio e botão de pedido instantâneo no WhatsApp.',
    outcome:
      'Os pedidos diretos sem intermediários cresceram 82% já nas primeiras semanas de divulgação.',
    image: '/assets/aistudio/image_6cc829cd.png',
    imageAlt: 'Site da hamburgueria Hambúrguer seu Oswaldo com chamada Chapa quente, sabor sem atalho e botão para WhatsApp',
    imageClassName: 'object-cover object-left',
    deliverables: ['Site Comercial & Cardápio', 'Conversão no WhatsApp', 'Design Mobile-First'],
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'depoimento-henrique',
    name: 'Henrique Almeida',
    role: 'Sócio-Diretor',
    company: 'Aurum Consultoria Financeira',
    city: 'São Paulo · SP',
    metric: '+164% em novos orçamentos',
    quote:
      'Antes tínhamos vergonha de enviar o link da empresa para clientes grandes. A KAVO Studio entregou o site novo no mesmo dia e, já no primeiro mês, o volume de reuniões comerciais mais que dobrou.',
  },
  {
    id: 'depoimento-camila',
    name: 'Dra. Camila Ferraz',
    role: 'Fundadora',
    company: 'Instituto BelleVie',
    city: 'Curitiba · PR',
    metric: '3,2x mais agendamentos',
    quote:
      'Precisávamos rodar uma campanha urgente e outras agências pediam 30 dias. Fechamos de manhã e à noite a página já estava no ar vendendo com um visual impecável no celular.',
  },
  {
    id: 'depoimento-rafael',
    name: 'Rafael Monteiro',
    role: 'Diretor Comercial',
    company: 'Kronos Horologia',
    city: 'Florianópolis · SC',
    metric: '+48% em conversão mobile',
    quote:
      'O nível de acabamento visual em azul marinho e metal deu outra autoridade para a nossa marca. Os clientes chegam no WhatsApp já decididos a comprar.',
  },
];
