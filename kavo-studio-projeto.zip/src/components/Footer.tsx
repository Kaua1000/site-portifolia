import { buildWhatsappUrl, CONTACT_INFO } from '../data/kavoData';

export function Footer() {
  return (
    <footer className="border-t border-slate-200/15 bg-[#05070C] py-10">
      <div className="mx-auto flex max-w-[1200px] flex-col gap-6 px-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <div className="flex items-center gap-3">
          <img
            src={CONTACT_INFO.logoUrl}
            alt="Logo KAVO Studio"
            referrerPolicy="no-referrer"
            className="h-9 w-9 rounded-lg object-cover metallic-hairline shrink-0"
          />
          <div>
            <p className="font-display text-base font-bold tracking-tight text-white">
              {CONTACT_INFO.brand}
            </p>
            <p className="mt-0.5 text-xs text-[#94A3B8]">
              Sua marca em outro nível <span aria-hidden="true">·</span> Entrega no mesmo dia{' '}
              <span aria-hidden="true">·</span> Brasil
            </p>
          </div>
        </div>

        <nav
          aria-label="Links do rodapé"
          className="flex flex-wrap items-center gap-5 text-xs sm:text-sm text-[#CBD5E1]"
        >
          <a href="#sobre" className="transition-colors hover:text-white whitespace-nowrap">
            Sobre
          </a>
          <a href="#servicos" className="transition-colors hover:text-white whitespace-nowrap">
            Serviços
          </a>
          <a href="#portfolio" className="transition-colors hover:text-white whitespace-nowrap">
            Portfólio
          </a>
          <a
            href={CONTACT_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-white whitespace-nowrap"
          >
            Instagram
          </a>
          <a
            href={buildWhatsappUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-white whitespace-nowrap"
          >
            WhatsApp
          </a>
        </nav>

        <p className="text-xs text-[#64748B]">© 2026 KAVO Studio. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}
