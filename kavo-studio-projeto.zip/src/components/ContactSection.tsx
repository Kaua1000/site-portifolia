import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowRight, CheckCircle2, Instagram, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsappUrl, CONTACT_INFO } from '../data/kavoData';

interface ContactSectionProps {
  preselectedService: string;
  focusTrigger: number;
}

const SERVICE_OPTIONS = [
  'Landing Page de Alta Conversão',
  'Site Institucional Premium',
  'Loja Virtual / Catálogo',
  'Reformulação Completa de Site',
];

interface FormErrors {
  name?: string;
  company?: string;
  phone?: string;
}

export function ContactSection({ preselectedService, focusTrigger }: ContactSectionProps) {
  const nameInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [phone, setPhone] = useState('');
  const [serviceType, setServiceType] = useState(SERVICE_OPTIONS[0]);
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  useEffect(() => {
    if (preselectedService) {
      const match = SERVICE_OPTIONS.find((opt) =>
        opt.toLowerCase().includes(preselectedService.toLowerCase().split(' ')[0]),
      );
      if (match) {
        setServiceType(match);
      }
    }
  }, [preselectedService]);

  useEffect(() => {
    if (focusTrigger > 0) {
      nameInputRef.current?.focus({ preventScroll: true });
    }
  }, [focusTrigger]);

  const validate = (): boolean => {
    const nextErrors: FormErrors = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    if (company.trim().length < 2) {
      nextErrors.company = 'Informe o nome da sua empresa.';
    }
    const digitsOnly = phone.replace(/\D/g, '');
    if (digitsOnly.length < 10) {
      nextErrors.phone = 'Informe um WhatsApp válido com DDD (ex: 49 99964-8153).';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validate()) return;

    const compiledBriefing = [
      `Olá, KAVO Studio! Quero solicitar um site para minha empresa.`,
      `Nome: ${name.trim()}`,
      `Empresa: ${company.trim()}`,
      `WhatsApp: ${phone.trim()}`,
      `Projeto desejado: ${serviceType}`,
      notes.trim() ? `Objetivo: ${notes.trim()}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    setSubmittedMessage(compiledBriefing);
  };

  const handleResetForm = () => {
    setSubmittedMessage(null);
    setName('');
    setCompany('');
    setPhone('');
    setNotes('');
    setErrors({});
  };

  return (
    <section id="contato" className="bg-[#05070C] py-16 sm:py-24">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-14">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs sm:text-sm font-medium text-[#94A3B8]">
              Solicitar Projeto <span aria-hidden="true">·</span> Atendimento Imediato
            </p>
            <h2 className="mt-3 font-display text-2xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
              Coloque sua empresa no ar ainda hoje e comece a converter mais clientes.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-[#D5DCE6]">
              Preencha o briefing ao lado para iniciar seu projeto com entrega no mesmo dia. Se
              preferir falar direto com nosso time comercial, chame agora pelo WhatsApp ou
              Instagram.
            </p>

            <div className="mt-8 space-y-4 border-t border-slate-200/15 pt-8">
              <a
                href={buildWhatsappUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl metallic-surface px-5 py-4 transition-colors hover:border-slate-200/35 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
              >
                <div className="flex items-center gap-3.5">
                  <MessageCircle className="h-5 w-5 shrink-0 text-white" aria-hidden="true" />
                  <div>
                    <p className="text-xs text-[#94A3B8]">WhatsApp Direto</p>
                    <p className="font-mono text-sm sm:text-base font-medium text-white tabular-nums">
                      {CONTACT_INFO.whatsappDisplay}
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-[#94A3B8]" aria-hidden="true" />
              </a>

              <a
                href={CONTACT_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl metallic-surface px-5 py-4 transition-colors hover:border-slate-200/35 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
              >
                <div className="flex items-center gap-3.5">
                  <Instagram className="h-5 w-5 shrink-0 text-white" aria-hidden="true" />
                  <div>
                    <p className="text-xs text-[#94A3B8]">Instagram Oficial</p>
                    <p className="text-sm sm:text-base font-medium text-white">
                      {CONTACT_INFO.instagramHandle}
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-[#94A3B8]" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="relative overflow-hidden rounded-2xl metallic-surface p-6 sm:p-8">
              <div
                aria-hidden="true"
                className="metallic-top-sheen absolute inset-x-0 top-0 h-px"
              />

              {submittedMessage ? (
                <div className="space-y-6 py-4" role="status" aria-live="polite">
                  <div className="flex items-start gap-3.5">
                    <CheckCircle2
                      className="mt-0.5 h-6 w-6 shrink-0 text-white"
                      aria-hidden="true"
                    />
                    <div>
                      <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
                        Solicitação preparada com sucesso
                      </h3>
                      <p className="mt-2 text-sm sm:text-base leading-relaxed text-[#CBD5E1]">
                        Recebemos os dados da <strong className="text-white">{company}</strong>.
                        Clique no botão abaixo para abrir seu atendimento imediato no WhatsApp da
                        KAVO Studio com todo o briefing preenchido e garantir sua entrega no mesmo
                        dia.
                      </p>
                    </div>
                  </div>

                  <div className="rounded-xl bg-[#05070C]/80 p-4 metallic-hairline">
                    <p className="text-xs font-medium text-[#94A3B8]">Resumo do pedido</p>
                    <p className="mt-2 whitespace-pre-line text-sm text-[#E2E8F0]">
                      {submittedMessage}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-4">
                    <a
                      href={buildWhatsappUrl(submittedMessage)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[48px] items-center gap-2.5 rounded-lg bg-white px-6 py-3 text-sm font-semibold text-[#05070C] transition-colors hover:bg-[#E2E8F0] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
                    >
                      <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span>Enviar agora pelo WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      onClick={handleResetForm}
                      className="inline-flex min-h-[48px] items-center px-3 py-2 text-sm font-medium text-[#CBD5E1] transition-colors hover:text-white cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
                    >
                      Editar informações
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="block text-sm font-medium text-[#E2E8F0]"
                      >
                        Seu nome
                      </label>
                      <input
                        ref={nameInputRef}
                        id="contact-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                        }}
                        placeholder="Ex: Lucas Ferreira"
                        aria-invalid={Boolean(errors.name)}
                        className="mt-2 min-h-[44px] w-full rounded-lg bg-[#05070C] px-4 py-2.5 text-sm text-white placeholder-[#64748B] metallic-hairline transition-colors focus:border-white focus:outline-none"
                      />
                      {errors.name && (
                        <p className="mt-1.5 text-xs text-[#FCA5A5]" role="alert">
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-company"
                        className="block text-sm font-medium text-[#E2E8F0]"
                      >
                        Nome da empresa
                      </label>
                      <input
                        id="contact-company"
                        type="text"
                        required
                        value={company}
                        onChange={(e) => {
                          setCompany(e.target.value);
                          if (errors.company)
                            setErrors((prev) => ({ ...prev, company: undefined }));
                        }}
                        placeholder="Ex: Ferreira Engenharia"
                        aria-invalid={Boolean(errors.company)}
                        className="mt-2 min-h-[44px] w-full rounded-lg bg-[#05070C] px-4 py-2.5 text-sm text-white placeholder-[#64748B] metallic-hairline transition-colors focus:border-white focus:outline-none"
                      />
                      {errors.company && (
                        <p className="mt-1.5 text-xs text-[#FCA5A5]" role="alert">
                          {errors.company}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-phone"
                        className="block text-sm font-medium text-[#E2E8F0]"
                      >
                        WhatsApp com DDD
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => {
                          setPhone(e.target.value);
                          if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                        }}
                        placeholder="(49) 99999-9999"
                        aria-invalid={Boolean(errors.phone)}
                        className="mt-2 min-h-[44px] w-full rounded-lg bg-[#05070C] px-4 py-2.5 text-sm text-white placeholder-[#64748B] metallic-hairline transition-colors focus:border-white focus:outline-none"
                      />
                      {errors.phone && (
                        <p className="mt-1.5 text-xs text-[#FCA5A5]" role="alert">
                          {errors.phone}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-service"
                        className="block text-sm font-medium text-[#E2E8F0]"
                      >
                        Tipo de projeto
                      </label>
                      <select
                        id="contact-service"
                        value={serviceType}
                        onChange={(e) => setServiceType(e.target.value)}
                        className="mt-2 min-h-[44px] w-full rounded-lg bg-[#05070C] px-4 py-2.5 text-sm text-white metallic-hairline transition-colors focus:border-white focus:outline-none"
                      >
                        {SERVICE_OPTIONS.map((option) => (
                          <option key={option} value={option} className="bg-[#0B1528] text-white">
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-notes"
                      className="block text-sm font-medium text-[#E2E8F0]"
                    >
                      O que sua empresa vende hoje? (opcional)
                    </label>
                    <textarea
                      id="contact-notes"
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Conte rapidamente seu segmento e qual resultado deseja alcançar com o novo site."
                      className="mt-2 w-full rounded-lg bg-[#05070C] px-4 py-3 text-sm text-white placeholder-[#64748B] metallic-hairline transition-colors focus:border-white focus:outline-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="inline-flex min-h-[48px] w-full items-center justify-center gap-2.5 rounded-lg bg-white px-6 py-3 text-sm sm:text-base font-semibold text-[#05070C] transition-all duration-150 hover:bg-[#E2E8F0] active:scale-[0.99] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
                    >
                      <span>{CONTACT_INFO.primaryCtaLabel}</span>
                      <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
