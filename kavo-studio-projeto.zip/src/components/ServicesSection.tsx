import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { CONTACT_INFO, SERVICES } from '../data/kavoData';

interface ServicesSectionProps {
  onPrimaryAction: (selectedService?: string) => void;
}

export function ServicesSection({ onPrimaryAction }: ServicesSectionProps) {
  return (
    <section
      id="servicos"
      className="border-b border-slate-200/10 bg-[#070B14] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="text-xs sm:text-sm font-medium text-[#94A3B8]">
              Serviços <span aria-hidden="true">·</span> Soluções em Criação de Sites
            </p>
            <h2 className="mt-3 font-display text-2xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
              Sites projetados para vender todos os dias e posicionar sua empresa no topo.
            </h2>
          </div>

          <p className="max-w-sm text-sm leading-relaxed text-[#CBD5E1]">
            Da página de vendas direta ao portal corporativo completo — com execução ágil e entrega
            no mesmo dia.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-5 lg:grid-cols-3">
          {SERVICES.map((service, index) => (
            <motion.article
              key={service.number}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.4, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className={`relative flex flex-col justify-between overflow-hidden rounded-2xl metallic-surface p-6 sm:p-8 ${
                service.span === 'wide' ? 'lg:col-span-2' : 'lg:col-span-1'
              }`}
            >
              <div
                aria-hidden="true"
                className="metallic-top-sheen absolute inset-x-0 top-0 h-px"
              />

              <div>
                <div className="flex items-center justify-between gap-4">
                  <span className="font-mono text-sm font-medium text-[#94A3B8] tabular-nums">
                    {service.number}
                  </span>
                  <span className="text-xs font-medium text-[#CBD5E1]">{service.highlight}</span>
                </div>

                <h3 className="mt-4 font-display text-xl sm:text-2xl font-semibold tracking-tight text-white">
                  {service.title}
                </h3>
                <p className="mt-1.5 text-xs sm:text-sm text-[#94A3B8]">{service.subtitle}</p>
                <p className="mt-4 text-sm sm:text-base leading-relaxed text-[#D5DCE6]">
                  {service.description}
                </p>
              </div>

              <div className="mt-6 pt-5 border-t border-slate-200/10">
                <button
                  type="button"
                  onClick={() => onPrimaryAction(service.title)}
                  className="inline-flex min-h-[40px] items-center gap-2 text-sm font-semibold text-white transition-colors duration-150 hover:text-[#CBD5E1] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2563EB]"
                >
                  <span>{CONTACT_INFO.primaryCtaLabel}</span>
                  <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
