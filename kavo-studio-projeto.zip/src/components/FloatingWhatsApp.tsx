import { MessageCircle } from 'lucide-react';
import { buildWhatsappUrl } from '../data/kavoData';

export function FloatingWhatsApp() {
  return (
    <a
      href={buildWhatsappUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar no WhatsApp com a KAVO Studio"
      className="fixed right-4 bottom-4 z-40 inline-flex min-h-[48px] items-center gap-2.5 rounded-full bg-[#0F1E3A] px-4 py-3 text-sm font-semibold text-white metallic-hairline shadow-xl transition-transform duration-150 hover:scale-[1.03] hover:bg-[#162C54] active:scale-[0.98] sm:right-6 sm:bottom-6 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
    >
      <MessageCircle className="h-5 w-5 shrink-0 text-white" aria-hidden="true" />
      <span className="hidden sm:inline whitespace-nowrap">Falar no WhatsApp</span>
    </a>
  );
}
