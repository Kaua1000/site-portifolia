import { motion } from 'motion/react';
import { TESTIMONIALS } from '../data/kavoData';

export function TestimonialsSection() {
  return (
    <section
      id="depoimentos"
      className="border-b border-slate-200/10 bg-[#070B14] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="max-w-2xl">
          <p className="text-xs sm:text-sm font-medium text-[#94A3B8]">
            Depoimentos <span aria-hidden="true">·</span> Clientes em todo o Brasil
          </p>
          <h2 className="mt-3 font-display text-2xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
            Empresas que aceleraram o faturamento depois de elevar sua presença digital.
          </h2>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((item, index) => (
            <motion.blockquote
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.4, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="relative flex flex-col justify-between overflow-hidden rounded-2xl metallic-surface p-6 sm:p-8"
            >
              <div
                aria-hidden="true"
                className="metallic-top-sheen absolute inset-x-0 top-0 h-px"
              />

              <div>
                <p className="font-mono text-xs font-medium text-[#CBD5E1] tabular-nums">
                  {item.metric}
                </p>
                <p className="mt-4 text-sm sm:text-base leading-relaxed text-[#E2E8F0]">
                  &ldquo;{item.quote}&rdquo;
                </p>
              </div>

              <footer className="mt-6 border-t border-slate-200/10 pt-5">
                <p className="font-display text-base font-semibold text-white">{item.name}</p>
                <p className="mt-0.5 text-xs sm:text-sm text-[#94A3B8]">
                  {item.role} <span aria-hidden="true">·</span> {item.company}
                </p>
                <p className="mt-0.5 text-xs text-[#64748B]">{item.city}</p>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
