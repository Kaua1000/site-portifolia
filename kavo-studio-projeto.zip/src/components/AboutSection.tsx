import { ArrowRight, Clock, ShieldCheck, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';
import { CONTACT_INFO } from '../data/kavoData';

interface AboutSectionProps {
  onPrimaryAction: () => void;
}

const PILLARS = [
  {
    icon: Clock,
    title: 'Entrega no mesmo dia',
    detail:
      'Enquanto agências tradicionais levam semanas em reuniões intermináveis, nossa equipe coloca seu site profissional no ar no mesmo dia.',
  },
  {
    icon: TrendingUp,
    title: 'Arquitetura focada em faturamento',
    detail:
      'Cada bloco, título e botão é pensado para conduzir o visitante até o pedido de orçamento ou fechamento direto no WhatsApp.',
  },
  {
    icon: ShieldCheck,
    title: 'Estética executiva de alto contraste',
    detail:
      'Construímos interfaces escuras, rápidas e responsivas que elevam a percepção de valor da sua empresa desde o primeiro segundo.',
  },
];

export function AboutSection({ onPrimaryAction }: AboutSectionProps) {
  return (
    <section id="sobre" className="border-b border-slate-200/10 bg-[#05070C] py-16 sm:py-24">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-14">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs sm:text-sm font-medium text-[#94A3B8]">
              Sobre a KAVO Studio <span aria-hidden="true">·</span> Quem Somos
            </p>
            <h2 className="mt-3 font-display text-2xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
              Uma agência jovem criada para elevar o nível das empresas brasileiras.
            </h2>
            <p className="mt-5 text-base leading-relaxed text-[#D5DCE6]">
              A KAVO Studio nasceu nos últimos meses com um propósito direto: tirar empresas sérias
              do amadorismo digital sem fazê-las esperar semanas por um site. Unimos direção visual
              premium, copywriting comercial e agilidade extrema para transformar sua presença online
              em um ativo de vendas imediato.
            </p>
            <p className="mt-4 text-base leading-relaxed text-[#94A3B8]">
              Atendemos negócios em todo o Brasil que precisam vender mais hoje — seja lançando uma
              operação do zero ou reposicionando a marca para cobrar mais caro pelo que já entrega.
            </p>

            <div className="mt-8">
              <button
                type="button"
                onClick={onPrimaryAction}
                className="inline-flex min-h-[48px] items-center gap-2.5 rounded-lg bg-[#0D1A33] px-6 py-3 text-sm font-semibold text-white metallic-hairline transition-all duration-150 hover:bg-[#14274A] active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
              >
                <span>{CONTACT_INFO.primaryCtaLabel}</span>
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </button>
            </div>
          </motion.div>

          <div className="lg:col-span-7 flex flex-col justify-center gap-5">
            {PILLARS.map((pillar, index) => {
              const Icon = pillar.icon;
              return (
                <motion.div
                  key={pillar.title}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.4, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
                  className="relative overflow-hidden rounded-2xl metallic-surface p-6 sm:p-7"
                >
                  <div
                    aria-hidden="true"
                    className="metallic-top-sheen absolute inset-x-0 top-0 h-px"
                  />
                  <div className="flex items-start gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#112242] text-white metallic-hairline">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <div>
                      <h3 className="font-display text-lg font-semibold text-white">
                        {pillar.title}
                      </h3>
                      <p className="mt-2 text-sm sm:text-base leading-relaxed text-[#CBD5E1]">
                        {pillar.detail}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
