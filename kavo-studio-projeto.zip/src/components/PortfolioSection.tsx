import { useEffect, useState } from 'react';
import { ArrowRight, ArrowUpRight, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  CONTACT_INFO,
  PORTFOLIO_PROJECTS,
  type PortfolioProject,
  type ProjectCategory,
} from '../data/kavoData';
import { ResilientImage } from './ResilientImage';

interface PortfolioSectionProps {
  onPrimaryAction: (selectedService?: string) => void;
}

const FILTER_OPTIONS: ProjectCategory[] = ['Todos', 'Landing Page', 'Institucional', 'E-commerce'];

export function PortfolioSection({ onPrimaryAction }: PortfolioSectionProps) {
  const [activeFilter, setActiveFilter] = useState<ProjectCategory>('Todos');
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const visibleProjects =
    activeFilter === 'Todos'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((project) => project.category === activeFilter);

  useEffect(() => {
    if (!selectedProject) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  return (
    <section
      id="portfolio"
      className="border-b border-slate-200/10 bg-[#05070C] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="text-xs sm:text-sm font-medium text-[#94A3B8]">
              Portfólio <span aria-hidden="true">·</span> Projetos Entregues
            </p>
            <h2 className="mt-3 font-display text-2xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
              Resultados reais construídos com design de alto contraste e entrega imediata.
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Filtrar projetos por categoria"
            className="inline-flex flex-wrap items-center gap-1 rounded-xl bg-[#0B1528] p-1 metallic-hairline self-start lg:self-auto"
          >
            {FILTER_OPTIONS.map((category) => {
              const isActive = activeFilter === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveFilter(category)}
                  className={`min-h-[36px] rounded-lg px-3.5 py-1.5 text-xs sm:text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB] ${
                    isActive
                      ? 'bg-white text-[#05070C]'
                      : 'text-[#CBD5E1] hover:text-white'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2">
          {visibleProjects.map((project, index) => (
            <motion.article
              key={project.id}
              layout
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.4, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="group relative flex flex-col overflow-hidden rounded-2xl metallic-surface"
            >
              <div
                aria-hidden="true"
                className="metallic-top-sheen absolute inset-x-0 top-0 z-10 h-px"
              />

              <button
                type="button"
                onClick={() => setSelectedProject(project)}
                className="flex flex-1 flex-col text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#2563EB]"
              >
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#0B1528]">
                  <ResilientImage
                    src={project.image}
                    alt={project.imageAlt}
                    title={project.title}
                    className={`h-full w-full transition-transform duration-300 ease-out group-hover:scale-[1.03] ${
                      project.imageClassName ?? 'object-cover'
                    }`}
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#070C17]/80 via-transparent to-transparent"
                  />
                </div>

                <div className="flex flex-1 flex-col justify-between p-6 sm:p-7">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#94A3B8]">
                      <span>{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.deliveryTime}</span>
                    </div>

                    <div className="mt-2.5 flex items-start justify-between gap-4">
                      <h3 className="font-display text-xl sm:text-2xl font-semibold tracking-tight text-white">
                        {project.title}
                      </h3>
                      <ArrowUpRight
                        className="mt-1 h-5 w-5 shrink-0 text-[#94A3B8] transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-white"
                        aria-hidden="true"
                      />
                    </div>

                    <p className="mt-2 text-sm leading-relaxed text-[#CBD5E1]">{project.summary}</p>
                  </div>

                  <div className="mt-5 border-t border-slate-200/10 pt-4">
                    <p className="font-mono text-xs sm:text-sm font-medium text-white tabular-nums">
                      {project.headlineMetric}
                    </p>
                  </div>
                </div>
              </button>
            </motion.article>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 rounded-2xl metallic-surface p-6 sm:flex-row sm:items-center sm:p-8">
          <div>
            <p className="font-display text-lg sm:text-xl font-semibold text-white">
              Quer um resultado semelhante para o seu negócio?
            </p>
            <p className="mt-1 text-sm text-[#CBD5E1]">
              Estruturamos o projeto da sua empresa com entrega no mesmo dia.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onPrimaryAction()}
            className="inline-flex min-h-[48px] items-center gap-2.5 rounded-lg bg-white px-6 py-3 text-sm font-semibold text-[#05070C] transition-all duration-150 hover:bg-[#E2E8F0] active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
          >
            <span>{CONTACT_INFO.primaryCtaLabel}</span>
            <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-project-title"
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070C]/85 p-4 backdrop-blur-md"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 12 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(event) => event.stopPropagation()}
              className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl metallic-surface shadow-2xl"
            >
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                aria-label="Fechar detalhes do projeto"
                className="absolute top-4 right-4 z-20 flex h-10 w-10 items-center justify-center rounded-lg bg-[#05070C]/85 text-white metallic-hairline transition-colors hover:bg-white hover:text-[#05070C] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>

              <div
                className={`w-full overflow-hidden bg-[#05070C] ${
                  selectedProject.imageClassName ? 'aspect-video' : 'aspect-[4/3]'
                }`}
              >
                <ResilientImage
                  src={selectedProject.image}
                  alt={selectedProject.imageAlt}
                  title={selectedProject.title}
                  className={`h-full w-full ${selectedProject.imageClassName ?? 'object-cover'}`}
                />
              </div>

              <div className="p-6 sm:p-8">
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#94A3B8]">
                  <span>{selectedProject.client}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.deliveryTime}</span>
                </div>

                <h3
                  id="modal-project-title"
                  className="mt-2 font-display text-2xl sm:text-3xl font-bold text-white"
                >
                  {selectedProject.title}
                </h3>

                <p className="mt-2 font-mono text-sm font-medium text-[#CBD5E1] tabular-nums">
                  {selectedProject.headlineMetric}
                </p>

                <div className="mt-6 grid grid-cols-1 gap-6 border-t border-slate-200/15 pt-6 sm:grid-cols-3">
                  <div>
                    <h4 className="text-xs font-semibold text-[#94A3B8]">Desafio</h4>
                    <p className="mt-2 text-sm leading-relaxed text-[#D5DCE6]">
                      {selectedProject.challenge}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-[#94A3B8]">Solução KAVO Studio</h4>
                    <p className="mt-2 text-sm leading-relaxed text-[#D5DCE6]">
                      {selectedProject.solution}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-[#94A3B8]">Resultado</h4>
                    <p className="mt-2 text-sm leading-relaxed text-white">
                      {selectedProject.outcome}
                    </p>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200/15 pt-6">
                  <p className="text-xs text-[#94A3B8]">
                    {selectedProject.deliverables.join(' · ')}
                  </p>

                  <button
                    type="button"
                    onClick={() => {
                      const category = selectedProject.category;
                      setSelectedProject(null);
                      onPrimaryAction(category);
                    }}
                    className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-[#05070C] transition-colors hover:bg-[#E2E8F0] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
                  >
                    <span>{CONTACT_INFO.primaryCtaLabel}</span>
                    <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
