import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { CONTACT_INFO, HERO_IMAGE, HERO_METRICS } from '../data/kavoData';
import { ResilientImage } from './ResilientImage';

interface HeroSectionProps {
  onPrimaryAction: () => void;
}

export function HeroSection({ onPrimaryAction }: HeroSectionProps) {
  return (
    <section
      id="inicio"
      className="relative overflow-hidden border-b border-slate-200/10 bg-[#05070C] pt-10 pb-14 sm:pt-16 sm:pb-20"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,rgba(29,78,216,0.22),transparent)]"
      />

      <div className="relative mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-6"
          >
            <p className="text-xs sm:text-sm font-medium tracking-wide text-[#94A3B8]">
              Agência Digital <span aria-hidden="true">·</span> Entrega no Mesmo Dia{' '}
              <span aria-hidden="true">·</span> Brasil
            </p>

            <h1 className="mt-4 max-w-xl font-display text-[clamp(2.35rem,4.5vw,3.9rem)] font-bold leading-[1.06] tracking-tight text-white [text-wrap:balance]">
              Sua marca em outro nível.
            </h1>

            <p className="mt-5 max-w-[58ch] text-base sm:text-lg leading-relaxed text-[#D5DCE6]">
              Criamos sites profissionais de alto padrão para empresas que querem aumentar seu
              faturamento. Estrutura persuasiva, visual escuro com acabamento metálico e{' '}
              <strong className="font-semibold text-white">entrega no mesmo dia</strong>.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onPrimaryAction}
                className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-lg bg-white px-6 py-3 text-sm sm:text-base font-semibold text-[#05070C] transition-all duration-150 hover:bg-[#E2E8F0] active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
              >
                <span>{CONTACT_INFO.primaryCtaLabel}</span>
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </button>

              <a
                href="#portfolio"
                className="inline-flex min-h-[48px] items-center gap-1.5 px-3 py-3 text-sm font-medium text-[#CBD5E1] transition-colors duration-150 hover:text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
              >
                <span>Ver projetos entregues</span>
                <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="relative flex h-full flex-col justify-between overflow-hidden rounded-2xl metallic-hairline bg-[#030711]">
              <div aria-hidden="true" className="metallic-top-sheen absolute inset-x-0 top-0 z-10 h-px" />
              <div className="relative flex flex-1 items-center justify-center overflow-hidden bg-[#030711] p-2 sm:p-3">
                <ResilientImage
                  src={HERO_IMAGE.src}
                  alt={HERO_IMAGE.alt}
                  title="KAVO Studio — Projeto em Destaque"
                  className="w-full rounded-lg object-contain"
                />
              </div>
              <div className="border-t border-slate-200/10 bg-[#070C17] px-5 py-4 sm:px-6">
                <p className="text-xs font-medium text-[#94A3B8]">
                  KAVO Studio <span aria-hidden="true">·</span> Padrão Corporativo &amp; Conversão
                </p>
                <p className="mt-1 text-sm sm:text-base font-medium text-white">
                  Design estratégico publicado em horas para acelerar suas vendas.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
          className="mt-10 grid grid-cols-2 gap-4 border-t border-slate-200/15 pt-8 lg:grid-cols-4 lg:gap-8"
        >
          {HERO_METRICS.map((metric) => (
            <div key={metric.label} className="space-y-1">
              <p className="font-mono text-xl sm:text-2xl font-medium tracking-tight text-white tabular-nums">
                {metric.value}
              </p>
              <p className="text-xs sm:text-sm text-[#94A3B8] leading-snug">{metric.label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
