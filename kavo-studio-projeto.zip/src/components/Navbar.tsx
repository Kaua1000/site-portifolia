import { ArrowRight } from 'lucide-react';
import { CONTACT_INFO } from '../data/kavoData';

interface NavbarProps {
  onPrimaryAction: () => void;
}

const NAV_LINKS = [
  { href: '#sobre', label: 'Sobre' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#portfolio', label: 'Portfólio' },
  { href: '#depoimentos', label: 'Depoimentos' },
];

export function Navbar({ onPrimaryAction }: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/15 bg-[#05070C]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-8 px-4 py-3 sm:px-6">
        <a
          href="#inicio"
          className="inline-flex items-center gap-2.5 font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2563EB]"
        >
          <img
            src={CONTACT_INFO.logoUrl}
            alt="Logo KAVO Studio"
            referrerPolicy="no-referrer"
            className="h-8 w-8 rounded-lg object-cover metallic-hairline shrink-0"
          />
          <span>{CONTACT_INFO.brand}</span>
        </a>

        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-6 text-sm font-medium text-[#CBD5E1]"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 transition-colors duration-150 hover:text-white whitespace-nowrap shrink-0 after:absolute after:bottom-0 after:left-0 after:h-px after:w-0 after:bg-white after:transition-all after:duration-200 hover:after:w-full focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2563EB]"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onPrimaryAction}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-white px-4 py-2 text-xs sm:text-sm font-semibold text-[#05070C] transition-all duration-150 hover:bg-[#E2E8F0] active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
          >
            <span className="hidden lg:inline">Solicitar um site para minha empresa</span>
            <span className="lg:hidden">Solicitar site</span>
            <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </button>
        </div>
      </div>
    </header>
  );
}
