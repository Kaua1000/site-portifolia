/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { Navbar } from './components/Navbar';
import { PortfolioSection } from './components/PortfolioSection';
import { ServicesSection } from './components/ServicesSection';
import { TestimonialsSection } from './components/TestimonialsSection';

export default function App() {
  const [preselectedService, setPreselectedService] = useState('');
  const [focusTrigger, setFocusTrigger] = useState(0);

  const handlePrimaryAction = (selectedService?: string) => {
    if (selectedService) {
      setPreselectedService(selectedService);
    }
    const contactEl = document.getElementById('contato');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setFocusTrigger((count) => count + 1);
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#05070C] text-white">
        <Navbar onPrimaryAction={() => handlePrimaryAction()} />

        <main>
          <HeroSection onPrimaryAction={() => handlePrimaryAction()} />
          <AboutSection onPrimaryAction={() => handlePrimaryAction()} />
          <ServicesSection onPrimaryAction={handlePrimaryAction} />
          <PortfolioSection onPrimaryAction={handlePrimaryAction} />
          <TestimonialsSection />
          <ContactSection
            preselectedService={preselectedService}
            focusTrigger={focusTrigger}
          />
        </main>

        <Footer />
        <FloatingWhatsApp />
      </div>
    </MotionConfig>
  );
}
